<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController extends Controller
{
    public function show()
    {
        return view('form');
    }
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'titel' => 'required|string|min:3|max:32',
            'artiest' => 'required|string|min:6|max:32',
            'jaar' => 'required|integer',
        ]);
        
        return redirect()->route('form')->with('success', 'Form submitted successfully!');
    }

}
